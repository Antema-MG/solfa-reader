# Convention officielle du format `.msolfa`

> Version définitive v2 — toutes règles consolidées

---

## 1. EN-TÊTE (optionnel avec valeurs par défaut)

Les 5 lignes suivantes sont **recommandées** mais optionnelles :

```
Key: [lettre majuscule, ex: G, Eb, D, F]
Mesure: [numérateur]/[dénominateur]
Titre: [texte libre ou -]
Compositeur: [texte libre]
Tempo: [nombre] BPM
```

### Valeurs par défaut si absent

| Champ | Défaut |
|---|---|
| `Key` | `C` (Do majeur) |
| `Mesure` | `4/4` |
| `Titre` | *(vide)* |
| `Compositeur` | *(vide)* |
| `Tempo` | *(non défini)* |

Exemples valides de `Key` : `C`, `G`, `D`, `F`, `Eb`, `Ab`, `Bb`

---

## 2. STRUCTURE DES BARRES

| Symbole | Rôle |
|---|---|
| `\|\|` | Ouvre **et** ferme une phrase musicale |
| `\|` | Sépare les mesures à l'intérieur d'une phrase |
| `:` | Sépare les temps à l'intérieur d'une mesure |
| `\|\| ... \| ... \|\|` | Phrase complète |

### Règle fondamentale

```
S. || mesure1 | mesure2 || mesure3 | mesure4 ||
```

- `||` ouvre la première phrase
- `|` sépare les mesures dans la phrase
- `||` ferme la phrase ET ouvre la suivante simultanément
- `||` final ferme la dernière phrase
- **Une seule ligne par voix**, sans retour à la ligne
- **Pas d'indentation** ni d'alinéa

---

## 3. LES VOIX

Chaque ligne de musique contient les voix dans cet ordre.  
Les voix **manquantes sont tolérées** — seules les voix présentes sont notées :

```
S. || ... ||    ← Soprano   (optionnel)
A. || ... ||    ← Alto      (optionnel)
T. || ... ||    ← Ténor     (optionnel)
B. || ... ||    ← Basse     (optionnel)
W. texte        ← Paroles   (optionnel)
```

---

## 4. COMPTAGE DES TEMPS PAR MESURE

Le numérateur de `Mesure` définit le nombre de temps par bloc :

| Mesure | Temps par mesure | `:` par bloc |
|---|---|---|
| `1/4` | 1 temps | 0 `:` |
| `2/4` | 2 temps | 1 `:` |
| `3/4` | 3 temps | 2 `:` |
| `4/4` | 4 temps | 3 `:` |
| `6/4` | 6 temps | 5 `:` |
| `6/8` | 6 temps | 5 `:` |

Exemple en `3/4` :
```
|| d:r:m | s:l:t ||
   ↑ 3 temps ↑ 3 temps
```

---

## 5. NOTES DE BASE

| Symbole | Note |
|---|---|
| `d` | Do |
| `r` | Ré |
| `m` | Mi |
| `f` | Fa |
| `s` | Sol |
| `l` | La |
| `t` ou `ti` | Si |

> `t` et `ti` sont **équivalents** — même note Si naturel.

---

## 6. ALTÉRATIONS CHROMATIQUES

### Suffixe `i` = dièse ♯ (monte d'un demi-ton)

| Symbole | Note |
|---|---|
| `di` | Do♯ |
| `ri` | Ré♯ |
| `fi` | Fa♯ |
| `si` | Sol♯ (**≠ note Si**, qui est `t` ou `ti`) |
| `li` | La♯ |
| `ti` | Si naturel (forme longue de `t`) |

### Suffixe `a` = bémol ♭ (descend d'un demi-ton)

| Symbole | Note |
|---|---|
| `ra` | Ré♭ |
| `ma` | Mi♭ |
| `fa` | Fa♭ (rare) |
| `la` | La♭ |
| `ta` | Si♭ (= Ti bémol) |

---

## 7. MODIFICATEURS D'OCTAVE

Collés **immédiatement** après la note (et son altération), **sans espace** :

| Modificateur | Sens |
|---|---|
| `'` | Octave aigu |
| `''` | Double octave aigu |
| `,` | Octave grave |
| `,,` | Double octave grave |

### Ordre obligatoire : `[note][altération][octave]`

```
fi'    → Fa♯ aigu
fi,    → Fa♯ grave
ta'    → Si♭ aigu
ta,    → Si♭ grave
si'    → Sol♯ aigu
d''    → Do double aigu
s,,    → Sol double grave
ti,    → Si grave
```

---

## 8. VALEURS RYTHMIQUES

Chaque **position entre deux `:` ** vaut **1 temps** :

| Symbole | Valeur | Description |
|---|---|---|
| `m` | 1 temps | Note simple |
| `-` | 1 temps | Prolongation / tenu |
| `0` | 1 temps | Silence |
| `_` | 1 temps | Silence (forme alternative) |
| *(vide)* | 1 temps | Silence (case vide) |
| `d.` | 1 temps | Note pointée (0.5 + 0.5 tenu) |
| `s.f` | 1 temps | Deux croches (0.5 + 0.5) |
| `-.s` | 1 temps | Prolongation + note de passage rapide |

> `0` = `_` = *(rien)* → tous les trois signifient **silence**.

---

## 9. ANACROUSE

Une mesure incomplète en début de phrase s'indique avec `:` précédant la première note :

```
S. || :m | r:d ||
      ↑ anacrouse (1 temps avant le temps fort)
```

En `3/4` avec anacrouse de 1 temps :
```
S. || :d | r:m:f ||
```

---

## 10. PAROLES (optionnel)

La ligne `W.` place les syllabes alignées sous les voix :

```
S. || m:-.m | r:d  ||
W. Je- sus    Sei-gneur
```

- Séparateur syllabique : `-` dans le texte
- Alignement visuel sous les notes correspondantes

---

## 11. ERREURS FRÉQUENTES

```
// ERREUR — mauvais nombre de temps en 2/4
S. || d:r:m | f:s ||      ← 3 temps au lieu de 2 dans la 1ère mesure

// ERREUR — modificateur avec espace
S. || d ' : r ||           ← espace avant ' interdit → correct : d'

// ERREUR — ordre altération/octave inversé
S. || 'fi : r ||           ← ' avant la note interdit → correct : fi'

// ERREUR — || non fermé
S. || d:r | m:f |          ← phrase non fermée
```

---

## 12. RÉSUMÉ SYNTAXIQUE

```
[EN-TÊTE — optionnel, défaut C / 4/4]

S. || t1:t2 | t1:t2 || t1:t2 | t1:t2 ||
A. || t1:t2 | t1:t2 || t1:t2 | t1:t2 ||
T. || t1:t2 | t1:t2 || t1:t2 | t1:t2 ||
B. || t1:t2 | t1:t2 || t1:t2 | t1:t2 ||
W. [paroles optionnelles]
```
